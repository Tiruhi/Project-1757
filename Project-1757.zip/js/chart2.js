var singleVisits = document.getElementById('singleVisits').getContext('2d');

// Chart.defaults.global.defaultFontFamily = "Lato";
// Chart.defaults.global.defaultFontSize = 18;

var dataFirst = {
    borderWidth: 4,
    label: "12",
    borderColor: 'rgb(255, 99, 132)',
    fill: true,
    data: [{
        x: 0,
        y: 0
    }, {
        x: 12,
        y: 0
    }],
    // radius: 5,
    // fill: 'none',
    // borderDash: [1, 1],
    // clip: true,
    // steppedLine: true,
    responsive: true,
    // order: 5,

    // pointRadius: 5,

};


var speedData = {
    datasets: [dataFirst],
    borderColor: '#e8e8e8',
    options: {

        tooltips: {
            mode: 'dataset',
        },
        // hover: {
        //     mode: 'nearest',
        //     intersect: true
        // },

    }
};


var lineChart = new Chart(singleVisits, {
    type: 'line',
    align: 'start',
    data: speedData,
    // showLines: true,
    options: {
        // hover: {
        //     mode: 'nearest',
        //     intersect: true
        // },
        title: {},
        legend: {
            display: false,
            // labels: {
            //     usePointStyle: true
            // }
        },
        tooltips: {},
        animation: {
            easing: 'easeInOutQuad',
            duration: 520
        },
        scales: {
            scale: {
                ticks: {
                    display: false,
                    // maxTicksLimit: 3
                    // beginAtZero: true
                }
            },
            yAxes: [{
                ticks: {
                    beginAtZero: true
                },
                display: false,

                gridLines: {
                    // drawBorder: true,
                    // display: false,
                    // lineWidth: 0
                }
            }],
            yAxes: [{
                display:false,
                ticks: {
                    beginAtZero: true
                },
                gridLines: {
                    // drawOnChartArea: false,
                    // display: false,
                    // lineWidth: 0
                }
            }]

        }
    }
});
var singleVisits = document.getElementById('singleVisits').getContext('2d');

var dataFirst = {
    borderWidth: 4,
    label: "12",
    borderColor: 'rgb(255, 99, 132)',
    pointBackgroundColor: 'rgb(255, 99, 132)',
    pointRadius: [0,5],

    fill: true,
    data: [{
        x: 0,
        y: 0
    }, {
        x: 12,
        y: 0
    },
    ],
    responsive: true,

};
var dataSecond = {

    borderWidth: 4,
    label: "15",
    borderColor: 'rgb(82,72,74)',
    pointBackgroundColor: 'rgb(255, 99, 132)',
    fill: true,
    data: [{
        x: 5,
        y: 8
    }, {
        x: 15,
        y: 0
    }],
    options: {
        elements: {
            point: {
                radius: 0
            }
        }
    }

};

var speedData = {
    datasets: [dataFirst, dataSecond],
};


var lineChart = new Chart(singleVisits, {
    type: 'line',
    align: 'start',
    responsive: true,

    data: speedData,


    options: {
        //     title: {
        //         // display: true,
        //         // text: 'Custom Chart Title'
        //     },
        legend: {
            display: false,
        },
        //     tooltips: {},
        animation: {
            easing: 'easeInOutQuad',
            duration: 520
        },
        scales: {
            yAxes: [{
                display: false,
                ticks: {
                    beginAtZero: true
                },
                gridLines: {
                    lineWidth: 1
                },

            }],
            xAxes: [{
                display: false,
                ticks: {
                    beginAtZero: true
                },
                gridLines: {
                    lineWidth: 2
                },
                // barPercentage: 2,
                // categoryPercentage: 0.9
            }],
        }

    },

});


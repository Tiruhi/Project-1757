$(document).ready(function () {
    $('.select-artist').select2();

});

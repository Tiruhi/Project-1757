var dataSecond = {

    data: [0, 1],
    lineWidth: 12,
    // backgroundColor: 'rgb(255, 99, 132)',
    borderColor: 'rgb(255, 99, 132)',
    lineTension: 0,
    fill: false,
    radius: 5,
    pointStyle: 'circle',
    borderWidth: 5

};

var singleVisits = document.getElementById('singleVisits').getContext('2d');


var singleVisits1 = document.getElementById("singleVisits1");

// Chart.defaults.global.defaultFontFamily = "Lato";
// Chart.defaults.global.defaultFontSize = 18;

var dataFirst = {
    // label: "12",
    borderWidth: 5,
    borderColor: 'rgb(255, 99, 132)',
    data: [{
        x: 0,
        y: 0
    }, {
        x: 12,
        y: 0
    }],
    radius: 5,
    fill: 'none',
    clip: true,
    steppedLine: true,
    responsive: true,
    order: 5,

    // showLine: false,
    // yAxisID: '1',
    // xAxisID: '5',

    // order: 15,
    pointRadius: 5,
    // lineTension: 0.1,

    // hoverBackgroundColor: [
    //     'blue'
    // ]

    // borderDash: [1,5],
    // borderDashOffset: 8.5,

};


var speedData = {
    // labels: ["0", "15"],
    datasets: [dataFirst],
    borderColor: '#e8e8e8',
    // backgroundColor: [
    //     pattern.draw('square', '#ff6384'),
    // ],
    options: {
        title: {
            display: true,
            text: 'Single Visits',
            // padding: 0,
            align: 'start',
            // events: ['click']


        },
        legend: {
            // lineWidth: 10,
            // lineDash: number[1,5],
            text: '21651sdv',
            display: false
        },
        tooltips: {
            mode: 'dataset',
            // axis: 'x'
        },

    }
};


var lineChart = new Chart(singleVisits, {
    type: 'line',
    // label: "Single Visits",
    align: 'start',
    data: speedData,
    backgroundColor: [
      //  pattern.draw('square', '#ff6384'),
        'square', '#ff6384'
    ],
    options: {
        title: {
            display: true,
            // text: 'Single Visits',
            padding: 0,
            align: 'start',
            // events: ['click']


        },
        legend: {
            // lineWidth: 10,
            // lineDash: number[1,5],
            // text: '21651sdv',
            display: false
        },
        tooltips: {
            // mode: 'dataset',
            // axis: 'x'
        },
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});